'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';

const RESOURCES = {"pell/pell.min.css": "1c7c1fcefc8355a04cac78e9c0e894fd",
"pell/pell.js": "d48fa5bf5d483e04b0d4744ba51e9ef1",
"flutter_bootstrap.js": "9e7e419b686b7e8f3688f506009f1025",
"version.json": "b3b5bcd1ceba4086eae1306363b09180",
"manifest.json": "6d27a6b82764089a5927e0ab84442147",
"assets/AssetManifest.json": "800838b04ea5fb420962d8ec74d83387",
"assets/assets/animations/network.json": "20b3437cf47099c8e7c355b774359d87",
"assets/assets/icons_g/vuesax/bold/airplane_square.svg": "8537fdfe7576c86039beced7b918faf9",
"assets/assets/icons_g/vuesax/bold/profile_add.svg": "c6932de6e772434af8fca0821c20ec8a",
"assets/assets/icons_g/vuesax/bold/user.svg": "7b75460aa246f7ff95ce12ce5c178628",
"assets/assets/icons_g/vuesax/bold/scan.svg": "76b2f1c2d53b1780902dd337c5b9f18a",
"assets/assets/icons_g/vuesax/bold/clock.svg": "2707b005df6940d346a10327365694ea",
"assets/assets/icons_g/vuesax/bold/arrow_circle_down.svg": "db90e48104a86888eb7f38778859fd03",
"assets/assets/icons_g/vuesax/bold/calendar_tick.svg": "968f51c5e49bb30d4463e2d757c48383",
"assets/assets/icons_g/home.svg": "b3a3c3c74262bd9f1f07706d454f220c",
"assets/assets/icons_g/bold/notes/clipboard_check.svg": "b64823e0060a04f8d1b434b95258adf2",
"assets/assets/icons_g/bold/notes/document_add.svg": "3f6ea4340fbd400afe066b7acbd67d37",
"assets/assets/icons_g/bold/like/star_shine.svg": "8773d0943f7ccdde3ed3099ab7fe560c",
"assets/assets/icons_g/bold/money/sale.svg": "f13bb9cc40c52e949c4f7bd75644b874",
"assets/assets/icons_g/group_1597878983.svg": "9260b4da5a869beb53e0d6565f34a2ac",
"assets/assets/icons_g/home_icon.svg": "1c3c82ae84d81f068f7b0ba0ad779f80",
"assets/assets/fonts/Vazir-Regular.ttf": "ea8cfea19e17fec2f5a76a76aaf23860",
"assets/assets/fonts/Vazir-Thin.ttf": "24abcd2229462232c025d90b63196a48",
"assets/assets/fonts/Vazir-Bold.ttf": "e5dd55b99484565a6737631963bf6fe7",
"assets/assets/fonts/Vazir-Light.ttf": "d014584aa14a5ccc61953f22071c9301",
"assets/assets/fonts/Vazir-Medium.ttf": "b546bbd8f52be1ed3a1b84aae6e1b60d",
"assets/assets/fonts/damsuncrm.ttf": "c27c242343a67955a3cb9f0d6c212478",
"assets/assets/fonts/Vazir-Black.ttf": "fd4f023a19b2a46265f094c3fa479e07",
"assets/assets/fonts/b_ziba.ttf": "0be92be905af42ad6c6e1d7976cc9005",
"assets/assets/icons_png/work.png": "bbff1d43714b1f9146de9a76da4f92cd",
"assets/assets/icons_png/login_out.png": "cad64ee91edf71635d57a4a551085327",
"assets/assets/icons_png/extra_work.png": "650d881928e834b4cdf1ffa96717df86",
"assets/assets/icons_png/off.png": "093f87ca93305f5a5dc3a134a5c7db40",
"assets/assets/images/otp_bg.png": "ee92ad44165f7e9e520ccc14f853be4c",
"assets/assets/images/bar.png": "be9e44bc113b19ad836c27af8a59b055",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "e986ebe42ef785b27164c36a9abc7818",
"assets/shaders/ink_sparkle.frag": "ecc85a2e95f5e9f53123dcaf8cb9b6ce",
"assets/AssetManifest.bin.json": "750cd0d7f3cfbfa88e4cd4f74f834fb0",
"assets/fonts/MaterialIcons-Regular.otf": "95891d4ab9d53b63619e7b374a3cdd0d",
"assets/NOTICES": "b67586f90b29f7c56b2ddf6a886211e6",
"assets/AssetManifest.bin": "257bff58ca1d00449b52aa0d913e93b5",
"assets/FontManifest.json": "d0203655d229eaaaeb41e71d4f652ee3",
"icons/Icon-512.png": "a263554699b80a81d535c3bb028fed4d",
"icons/Icon-maskable-192.png": "b6794998f161755f18d0a5a75c70fa2d",
"icons/Icon-maskable-512.png": "a263554699b80a81d535c3bb028fed4d",
"icons/Icon-192.png": "b6794998f161755f18d0a5a75c70fa2d",
"canvaskit/skwasm.js.symbols": "262f4827a1317abb59d71d6c587a93e2",
"canvaskit/skwasm.wasm": "9f0c0c02b82a910d12ce0543ec130e60",
"canvaskit/skwasm.worker.js": "89990e8c92bcb123999aa81f7e203b1c",
"canvaskit/chromium/canvaskit.wasm": "b1ac05b29c127d86df4bcfbf50dd902a",
"canvaskit/chromium/canvaskit.js.symbols": "a012ed99ccba193cf96bb2643003f6fc",
"canvaskit/chromium/canvaskit.js": "671c6b4f8fcc199dcc551c7bb125f239",
"canvaskit/skwasm.js": "694fda5704053957c2594de355805228",
"canvaskit/canvaskit.wasm": "1f237a213d7370cf95f443d896176460",
"canvaskit/canvaskit.js.symbols": "48c83a2ce573d9692e8d970e288d75f7",
"canvaskit/canvaskit.js": "66177750aff65a66cb07bb44b8c6422b",
"ponyfill.min.js": "b33006e573f931f13f65372d7f680763",
"StreamSaver.min.js": "275df3d0622366b09d249518b17fdd3e",
"favicon.png": "3f584c9523760fbbb0ae0d9e1d1e9347",
"flutter.js": "f393d3c16b631f36852323de8e583132",
"index.html": "49b2333d073fcc0473d546d58311f85c",
"/": "49b2333d073fcc0473d546d58311f85c",
"main.dart.js": "1f0fe3dd58010cf0179e278a964ca5d6"};
// The application shell files that are downloaded before a service worker can
// start.
const CORE = ["main.dart.js",
"index.html",
"flutter_bootstrap.js",
"assets/AssetManifest.bin.json",
"assets/FontManifest.json"];

// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value, {'cache': 'reload'})));
    })
  );
});
// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        // Claim client to enable caching on first launch
        self.clients.claim();
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      // Claim client to enable caching on first launch
      self.clients.claim();
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});
// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache only if the resource was successfully fetched.
        return response || fetch(event.request).then((response) => {
          if (response && Boolean(response.ok)) {
            cache.put(event.request, response.clone());
          }
          return response;
        });
      })
    })
  );
});
self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});
// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey of Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}
// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}
